
<style>

.laporan-rpjmd .head1 {
  background: #6a95ff;
  text-align: center;
  color: #ffffff;
  vertical-align: top;
  border-color: white;
  text-align: left;
}

.laporan-rpjmd .head2 {
  background: #6a95bf;
  text-align: center;
  color: #ffffff;
  vertical-align: top;
  border-color: white;
}


</style>

<div class="laporan-rpjmd">

  
<div style="text-align: center">
  <h5>Target Indikator Kinerja Utama Tahun</h5>
  <br>
</div>

<table class="table table-bordered" style="font-size: 14px;">
  <thead>
	<tr>
		<th width="50" class="head1">No</th>
	</tr>
  </thead>
  <tbody>
	<tr>
		<td>tes</td>
	</tr>
  </tbody>
</table>



</div>


